
package hasanitfirm;

import javax.swing.JFrame;
import view.LoginPage;


public class HasanITFirm {
   
     JFrame jframe = new JFrame("My JFrame Title");
     
    public static void main(String[] args) {
       
          LoginPage loginPage = new LoginPage();
        
       
        loginPage.setVisible(true);
            loginPage.setLocationRelativeTo(null);
        
      
    }
    
}



  
